# Summary

* [Введение](1-intro.md)
* [Термины](2-terms.md)
* [OTE/Fibo](3-ote-fibo.md)
* [Структура рынка](4-structure.md)
* [Чек-лист](5-checklist.md)
* [Кейсы](6-cases.md)
* [Глоссарий](7-glossary.md)
* [Выводы](8-conclusions.md)
