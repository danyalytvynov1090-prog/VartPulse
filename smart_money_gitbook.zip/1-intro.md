# Введение

Описание whitepaper Smart Money.
