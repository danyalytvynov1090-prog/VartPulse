# Smart Money — Whitepaper (Vart)

